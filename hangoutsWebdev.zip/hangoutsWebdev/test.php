<?php
echo "Server is working fine!";
?>
